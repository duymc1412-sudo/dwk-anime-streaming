# DWK ANIME

Full-stack starter for an ad-free anime discovery and licensed-video platform. Responsive dark UI, AniList metadata search, browser-local watchlist, Cloudflare Worker API, D1 schema, and private R2 upload endpoint.

## Included in this build
- Responsive mobile/desktop catalog UI inspired by the supplied references.
- Live AniList GraphQL search and anime detail API through the Worker (keeps provider calls server-side).
- Search, year/genre/format filters, pagination, detail modal, watchlist stored locally.
- HLS.js player shell with an explicit empty state until a licensed episode is configured.
- Cloudflare D1 schema for users, anime, episodes, watchlists, and watch progress.
- R2 upload endpoint protected by Cloudflare Access identity and an allowlisted admin email.

## Not yet production-complete
Google sign-in and cross-device account sync are not wired; configure Cloudflare Access (or implement a dedicated OAuth callback) before enabling account features. The R2 upload route stores private objects but does not expose public playback URLs. For production HLS, use Cloudflare Stream or a signed playback gateway with authorization, CORS, byte-range/segment delivery, and subtitle support. Do not publish unlicensed streams.

## Requirements
- Node.js 20+
- Cloudflare account
- Wrangler CLI (installed by `npm install`)

## Local setup
1. `npm install`
2. Create a D1 database: `npx wrangler d1 create dwk-db`
3. Copy the returned database ID into `wrangler.toml`.
4. Create an R2 bucket: `npx wrangler r2 bucket create dwk-media`
5. Apply schema: `npm run db:local`
6. Run locally: `npm run dev`

The AniList public GraphQL API does not require an API key for public catalog data. Respect its terms and rate limits; the API documentation currently reports temporary degraded capacity and a 30 requests/minute limit while restoration is underway: https://docs.anilist.co/guide/rate-limiting/.

## Production setup
1. `npm run db:remote`
2. In Cloudflare Zero Trust, create an Access application protecting `/api/admin/*` and `/admin/*`.
3. Set Worker secret/variable `ADMIN_EMAIL` to the exact administrator email allowed to upload.
4. Deploy: `npm run deploy`
5. Keep R2 private. Do not expose raw bucket credentials in the browser.

## Add a licensed episode
Insert an episode record after the video has been processed and a secure playback delivery URL has been provisioned. Example schema fields: `anime_id`, `episode_number`, `playback_url`, `playback_type`, `subtitle_url`, `subtitle_language`, `is_published`. The current UI intentionally does not pretend an anime is playable just because metadata exists.

## Environment / bindings
`wrangler.toml` defines `ASSETS`, `DB`, and `MEDIA`. Configure `ADMIN_EMAIL` as a Worker variable or secret. Replace the D1 `database_id` placeholder before deployment.

## Project structure
```
public/       responsive web app
src/          Cloudflare Worker API
migrations/   D1 schema
wrangler.toml Cloudflare bindings
```
