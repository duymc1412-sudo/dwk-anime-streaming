PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, display_name TEXT, avatar_url TEXT,
  role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS anime (
  id TEXT PRIMARY KEY, anilist_id INTEGER UNIQUE, title TEXT NOT NULL, title_native TEXT,
  description TEXT, cover_image TEXT, banner_image TEXT, genres_json TEXT NOT NULL DEFAULT '[]',
  season_year INTEGER, format TEXT, status TEXT, average_score REAL, source TEXT NOT NULL DEFAULT 'anilist',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS episodes (
  id TEXT PRIMARY KEY, anime_id TEXT NOT NULL REFERENCES anime(id) ON DELETE CASCADE,
  episode_number REAL NOT NULL, title TEXT, duration_seconds INTEGER,
  playback_url TEXT NOT NULL, playback_type TEXT NOT NULL DEFAULT 'hls' CHECK(playback_type IN ('hls','mp4')),
  subtitle_url TEXT, subtitle_language TEXT DEFAULT 'vi', is_published INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(anime_id, episode_number)
);
CREATE TABLE IF NOT EXISTS watchlist (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  anime_id TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(user_id, anime_id)
);
CREATE TABLE IF NOT EXISTS watch_progress (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  episode_id TEXT NOT NULL REFERENCES episodes(id) ON DELETE CASCADE,
  position_seconds REAL NOT NULL DEFAULT 0, duration_seconds REAL NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id, episode_id)
);
CREATE INDEX IF NOT EXISTS idx_episodes_anime ON episodes(anime_id, episode_number);
CREATE INDEX IF NOT EXISTS idx_progress_user ON watch_progress(user_id, updated_at DESC);
