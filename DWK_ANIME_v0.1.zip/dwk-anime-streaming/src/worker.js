const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
const safeText = (v, max = 300) => String(v ?? '').trim().slice(0, max);

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/')) {
      try { return await routeApi(request, env, url); }
      catch (err) { console.error(err); return json({ error: 'Internal server error' }, 500); }
    }
    return env.ASSETS.fetch(request);
  }
};

async function routeApi(request, env, url) {
  const path = url.pathname;
  if (request.method === 'GET' && path === '/api/health') return json({ ok: true, app: env.APP_NAME || 'DWK Anime', time: new Date().toISOString() });
  if (request.method === 'GET' && path === '/api/anime/search') {
    const search = safeText(url.searchParams.get('q'), 80);
    const page = Math.max(1, Math.min(20, Number(url.searchParams.get('page') || 1)));
    const perPage = Math.max(1, Math.min(30, Number(url.searchParams.get('perPage') || 18)));
    const query = `query ($search: String, $page: Int, $perPage: Int) { Page(page: $page, perPage: $perPage) { pageInfo { currentPage hasNextPage total } media(search: $search, type: ANIME, sort: POPULARITY_DESC) { id title { romaji english native } description(asHtml: false) coverImage { large extraLarge } bannerImage genres seasonYear format status averageScore episodes } } }`;
    const upstream = await fetch(env.ANILIST_ENDPOINT || 'https://graphql.anilist.co', { method: 'POST', headers: { 'content-type': 'application/json', 'accept': 'application/json' }, body: JSON.stringify({ query, variables: { search: search || null, page, perPage } }) });
    if (!upstream.ok) return json({ error: 'Anime catalog provider unavailable', retryAfter: upstream.headers.get('retry-after') }, 502);
    const body = await upstream.json();
    if (body.errors) return json({ error: 'Catalog query failed', details: body.errors.map(e => e.message) }, 502);
    return json({ pageInfo: body.data.Page.pageInfo, items: body.data.Page.media.map(mapAniList) });
  }
  if (request.method === 'GET' && path.startsWith('/api/anime/')) {
    const id = Number(path.split('/').pop());
    if (!Number.isInteger(id) || id < 1) return json({ error: 'Invalid anime ID' }, 400);
    const query = `query ($id: Int) { Media(id: $id, type: ANIME) { id title { romaji english native } description(asHtml: false) coverImage { large extraLarge } bannerImage genres seasonYear format status averageScore episodes studios(isMain: true) { nodes { name } } } }`;
    const upstream = await fetch(env.ANILIST_ENDPOINT || 'https://graphql.anilist.co', { method: 'POST', headers: { 'content-type': 'application/json', 'accept': 'application/json' }, body: JSON.stringify({ query, variables: { id } }) });
    if (!upstream.ok) return json({ error: 'Anime catalog provider unavailable' }, 502);
    const body = await upstream.json();
    if (!body.data?.Media) return json({ error: 'Anime not found' }, 404);
    return json(mapAniList(body.data.Media));
  }
  // Cloudflare Access protects /admin/*; the Worker trusts this identity header only behind an Access policy.
  if (path === '/api/admin/upload' && request.method === 'POST') {
    const email = request.headers.get('cf-access-authenticated-user-email');
    if (!email || !env.ADMIN_EMAIL || email.toLowerCase() !== env.ADMIN_EMAIL.toLowerCase()) return json({ error: 'Admin authentication required' }, 401);
    if (!env.MEDIA) return json({ error: 'R2 bucket binding is missing' }, 503);
    const form = await request.formData();
    const file = form.get('file');
    if (!(file instanceof File)) return json({ error: 'Missing file' }, 400);
    if (file.size > 1024 * 1024 * 1024) return json({ error: 'File exceeds 1 GB upload limit' }, 413);
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    if (!['m3u8','mp4','vtt','srt','ts','m4s','aac'].includes(ext)) return json({ error: 'Unsupported media extension' }, 415);
    const key = `library/${crypto.randomUUID()}.${ext}`;
    await env.MEDIA.put(key, file.stream(), { httpMetadata: { contentType: file.type || mimeFor(ext) }, customMetadata: { originalName: file.name, uploadedBy: email } });
    return json({ ok: true, key, message: 'Uploaded to private R2 storage. Configure an authorized playback delivery route before publishing.' }, 201);
  }
  if (path === '/api/me' && request.method === 'GET') {
    const email = request.headers.get('cf-access-authenticated-user-email');
    return json({ authenticated: Boolean(email), email: email || null, message: email ? 'Identity supplied by Cloudflare Access' : 'Guest mode' });
  }
  return json({ error: 'Not found' }, 404);
}

function mapAniList(m) {
  return { id: m.id, title: m.title?.english || m.title?.romaji || 'Untitled', titleRomaji: m.title?.romaji || '', titleNative: m.title?.native || '', description: m.description || '', cover: m.coverImage?.extraLarge || m.coverImage?.large || '', banner: m.bannerImage || '', genres: m.genres || [], year: m.seasonYear || null, format: m.format || '', status: m.status || '', score: m.averageScore ? m.averageScore / 10 : null, episodes: m.episodes || null, studios: m.studios?.nodes?.map(s => s.name) || [] };
}
function mimeFor(ext) { return ({ m3u8:'application/vnd.apple.mpegurl', mp4:'video/mp4', vtt:'text/vtt', srt:'application/x-subrip', ts:'video/mp2t', m4s:'video/iso.segment', aac:'audio/aac' })[ext] || 'application/octet-stream'; }
